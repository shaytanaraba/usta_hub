// Updated assets to use Data URIs for the circle logo to ensure visibility.

export const ASSETS = {
  // Simple circle logo (Red background, yellow construction helmet)
  LOGO_CIRCLE: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%23DC2626'/%3E%3Cpath d='M30 40 Q 50 20 70 40' fill='%23FDE047' stroke='white' stroke-width='2'/%3E%3Crect x='30' y='40' width='40' height='10' rx='2' fill='%23FDE047'/%3E%3Cpath d='M30 50 H 70 V 80 H 30 Z' fill='%23FDE047'/%3E%3Ctext x='50' y='75' text-anchor='middle' fill='white' font-weight='bold' font-size='20' font-family='sans-serif'%3EM%3C/text%3E%3C/svg%3E"
};