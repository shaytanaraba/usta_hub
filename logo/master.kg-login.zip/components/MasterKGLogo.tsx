import React from 'react';

export const MasterKGLogo: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 500 280" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Red Paint Splash Background */}
    <path 
      d="M467.5 73.5C487.5 101.5 480.2 145.2 467.5 168.5C458.6 184.8 440.5 198.5 417.5 203.5C399.9 207.3 358.5 204.5 322.5 206.5C252.3 210.4 181.7 208.2 112.5 203.5C92.2 202.1 66.8 198.2 52.5 183.5C42.8 173.5 44.5 155.8 47.5 142.5C52.1 121.8 62.5 103.5 77.5 88.5C98.8 67.2 135.5 61.8 162.5 58.5C215.1 52.1 270.6 51.1 322.5 58.5C362.2 64.1 445.8 43.1 467.5 73.5Z" 
      fill="#DC2626" 
    />
    <path d="M480 60 L 500 55 L 490 80 Z" fill="#DC2626"/> {/* Splatter detail */}
    <path d="M30 160 L 10 170 L 35 185 Z" fill="#DC2626"/> {/* Splatter detail */}

    {/* House Icon Outline */}
    <path d="M250 35 L 310 80 V 170 H 190 V 80 L 250 35" stroke="white" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M205 80 L 250 45 L 295 80" stroke="white" strokeWidth="3" strokeLinecap="round"/>
    {/* Chimney */}
    <rect x="210" y="50" width="12" height="20" fill="white" />

    {/* Builder Silhouette */}
    <g transform="translate(250, 130)">
       {/* Helmet */}
       <path d="M-25 -30 Q 0 -50 25 -30" fill="#FDE047" stroke="white" strokeWidth="2" />
       <rect x="-25" y="-30" width="50" height="8" rx="2" fill="#FDE047" />
       {/* Head */}
       <circle cx="0" cy="-10" r="18" fill="#FDE047" />
       {/* Body */}
       <path d="M-25 10 H 25 V 40 H -25 Z" fill="#FDE047" />
       {/* Overalls straps */}
       <path d="M-15 10 V 40" stroke="#DC2626" strokeWidth="3" />
       <path d="M15 10 V 40" stroke="#DC2626" strokeWidth="3" />
       {/* Buttons */}
       <circle cx="-15" cy="25" r="2.5" fill="#DC2626" />
       <circle cx="15" cy="25" r="2.5" fill="#DC2626" />
    </g>

    {/* Text: MASTER.KG */}
    <text x="250" y="215" textAnchor="middle" fill="white" fontFamily="Arial, sans-serif" fontWeight="900" fontSize="38" letterSpacing="1" style={{filter: 'drop-shadow(0px 2px 2px rgba(0,0,0,0.1))'}}>MASTER.KG</text>
    
    {/* Gears */}
    <g transform="translate(420, 190) rotate(15)">
      <path d="M10 0 L 12 4 L 16 4 L 17 8 L 21 10 L 19 14 L 21 16 L 17 18 L 16 22 L 12 20 L 10 24 L 6 22 L 4 18 L 0 16 L 2 12 L -2 8 L 4 8 L 5 4 Z" fill="#FDE047" />
      <circle cx="10" cy="12" r="3" fill="#DC2626" />
    </g>
    <g transform="translate(438, 180) scale(0.7) rotate(-15)">
      <path d="M10 0 L 12 4 L 16 4 L 17 8 L 21 10 L 19 14 L 21 16 L 17 18 L 16 22 L 12 20 L 10 24 L 6 22 L 4 18 L 0 16 L 2 12 L -2 8 L 4 8 L 5 4 Z" fill="#FDE047" />
      <circle cx="10" cy="12" r="3" fill="#DC2626" />
    </g>

    {/* Subtext inside the splash */}
    <text x="250" y="235" textAnchor="middle" fill="white" fontFamily="Arial, sans-serif" fontWeight="600" fontSize="10" letterSpacing="2">ЭНЕРГИЯ И ТЕПЛО ВАШЕГО ДОМА!</text>
    
    {/* Paint brush handle detail (bottom left) */}
    <path d="M60 190 Q 50 200 40 215 L 30 240 L 50 245 L 65 220 Q 75 205 60 190" fill="#DC2626"/>
    <path d="M30 240 L 25 250 L 45 255 L 50 245" fill="#FDE047"/>
    <path d="M25 250 L 20 260 Q 30 270 45 260 L 45 255" fill="#DC2626"/>
  </svg>
);
